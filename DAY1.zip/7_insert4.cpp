#include <iostream>
#include <list>
#include <algorithm>

template<typename C>
class eback_insert_iterator
{
};

int main()
{
	list<int> s = { 1,2 };
	eback_insert_iterator<std::list<int>> p(s);

	*p = 30; // ( p.operator*() ).operator=(30)

	for (auto& n : s)
		cout << n << ", ";
}
