#include <iostream>
#include <algorithm>
#include <vector>
#include <functional>

bool foo(int a)
{
    return a % 3 == 0;
}

int main()
{
    std::vector<int> v = {1,9,2,3,4,5,6,7}

    int k = 3;

    // 주어진 구간에서 k의 배수를 찾고 싶다.
    auto ret = std::find_if(v.begin(), v.end(), ? );
}

















//












//
