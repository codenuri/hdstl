#include <iostream>
#include <memory>

int main()
{
	int* p1 = new int;
	delete p1;

	int* p2 = new int;
	delete p2;

}