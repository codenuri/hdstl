#include <set> // Red Black Tree
#include <functional>

int main()
{
	std::set<int> s; // Red Black Tree �Դϴ�.

	s.insert(15);
	s.insert(25);
	s.insert(5);
	s.insert(17);
	s.insert(10);

	auto p = s.begin();

	while (p != s.end())
	{
		std::cout << *p << ", ";
		++p;
	}
	std::cout << std::endl;
}