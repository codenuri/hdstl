#include <vector>
#include "show.h"


int main()
{
	std::vector<int> v(3);

	std::cout << "------------" << std::endl;

	v.resize(10);

	std::cout << "------------" << std::endl;

}